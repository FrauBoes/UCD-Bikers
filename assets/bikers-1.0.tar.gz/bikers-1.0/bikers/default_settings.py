DEBUG = True  # make sure DEBUG is off unless enabled explicitly otherwise
LOG_DIR = '.'  # create log files in current working directory
